const root = document.querySelector(':root');
const galleryPics = document.querySelectorAll('.galleryPics');
const galleryBigImages = document.querySelectorAll('.galleryBigImages');
const closeGallery = document.getElementById('closeGallery')
const galleryList = [...galleryPics];
const toggleLeft = document.getElementById('toggleLeft');
const toggleRight = document.getElementById('toggleRight');

let selectedPictureNumber;

function toggleArrowFixer () {
    if(selectedPictureNumber === 1) {
        root.style.setProperty('--leftToggler', 'none');
    }else {
        root.style.setProperty('--leftToggler', 'initial');
    }
    if(selectedPictureNumber === galleryList.length){
        root.style.setProperty('--rightToggler', 'none');
    }else {
        root.style.setProperty('--rightToggler', 'initial');
    }
}

function imagePopper () {

    galleryBigImages.forEach((l) => {
        l.classList.remove('gallerySelectedBigImage')
    });
    let currentImage = 'galleryImage' + selectedPictureNumber;
    let selectedImage = document.getElementById(currentImage);
    selectedImage.classList.add('gallerySelectedBigImage');
    toggleArrowFixer();
}


for (let i = 0; i < galleryList.length; i++) {
    galleryList[i].addEventListener('click', () => {
        let windowWidth = window.innerWidth;
        if(windowWidth > 1023) {
            root.style.setProperty('--galleryFrame', 'initial');
            root.style.setProperty('--bodyHeight', 'hidden');
            selectedPictureNumber = (i+1);
            imagePopper();
        }
    })
}


closeGallery.addEventListener('click', () => {
    root.style.setProperty('--galleryFrame', 'none');
    root.style.setProperty('--bodyHeight', 'unset');
    galleryBigImages.forEach((l) => {
        l.classList.remove("gallerySelectedBigImage")
    });
})


toggleLeft.addEventListener('click', () => {
    selectedPictureNumber = selectedPictureNumber-1;
    imagePopper();
})

toggleRight.addEventListener('click', () => {
    selectedPictureNumber = selectedPictureNumber+1;
    imagePopper();
})

